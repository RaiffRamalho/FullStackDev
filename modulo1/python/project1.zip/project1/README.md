# Project 1 - Movie Trailer Website

This is the first project of the Udacity Nanodegree Course - Full Stack Developer

## Getting Started

This project its about to run a web site trailer of the preferid movies of the user

### Prerequisites

The user need to have Python 3.0.6 intalled in his machine

### Runing the Project

Run the comand line : Python entertainment_center.py
