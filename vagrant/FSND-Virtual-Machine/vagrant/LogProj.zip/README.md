# Logs Analysis Project

This is the modules 3  first project of udacity course of Fullstack Developer

## Prerequisites

* Set up described in the project specification
* Python 2.7 installed in the machine

## How to run

The file logProj.py need to be inside the vagrant folder.

```
python logProj.py
```

### Views created

* articlesPopular with columns (title, mostPop)
* authorPopularNum with columns (author, totalViews)
* errors with column (time)
* success with column (time)
* errorsCounted with columns (time, countin)
* successCounted with columns (time, countin)